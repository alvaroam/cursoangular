// Un módulo ES6 es un archivo que contiene código JS.
//  No existe una palabra clave module; 
    
export const hello = (nombre) => {
    return "Hola " + nombre;
}
